import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, Package, Download } from "lucide-react"
import Link from "next/link"

export default function FeaturedProducts() {
  const products = [
    {
      id: 1,
      name: "Hydraulic Valve A7E",
      sku: "HV-A7E-2024",
      image: "/placeholder.svg?height=200&width=200",
      price: "$120.00",
      moq: "20 pcs",
      stock: 120,
      rating: 4.8,
      supplier: "Industrial Solutions Inc.",
      location: "Ohio, USA",
      certifications: ["ISO 9001", "CE"],
      leadTime: "3-5 days",
    },
    {
      id: 2,
      name: "Precision Bearing Assembly",
      sku: "PBA-X200",
      image: "/placeholder.svg?height=200&width=200",
      price: "$85.50",
      moq: "50 pcs",
      stock: 340,
      rating: 4.9,
      supplier: "Precision Parts Co.",
      location: "Michigan, USA",
      certifications: ["ISO 9001", "IATF 16949"],
      leadTime: "2-4 days",
    },
    {
      id: 3,
      name: "Aviation Grade Fastener",
      sku: "AGF-7750",
      image: "/placeholder.svg?height=200&width=200",
      price: "$15.75",
      moq: "100 pcs",
      stock: 850,
      rating: 4.7,
      supplier: "Aerospace Components Ltd.",
      location: "California, USA",
      certifications: ["AS9100", "NADCAP"],
      leadTime: "1-3 days",
    },
  ]

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Featured Products</h2>
          <p className="text-lg text-gray-600">High-demand industrial components from certified suppliers</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="aspect-square bg-gray-100 rounded-lg mb-4 flex items-center justify-center">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-32 h-32 object-contain"
                  />
                </div>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{product.name}</CardTitle>
                    <CardDescription className="text-sm text-gray-500">SKU: {product.sku}</CardDescription>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{product.rating}</span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="text-2xl font-bold text-orange-600">{product.price}</div>
                  <Badge variant="outline">MOQ: {product.moq}</Badge>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Stock:</span>
                    <span className="font-medium">{product.stock} pcs</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Lead Time:</span>
                    <span className="font-medium">{product.leadTime}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{product.supplier}</span>
                  </div>
                  <div className="text-sm text-gray-500">{product.location}</div>
                </div>

                <div className="flex flex-wrap gap-1">
                  {product.certifications.map((cert) => (
                    <Badge key={cert} variant="secondary" className="text-xs">
                      {cert}
                    </Badge>
                  ))}
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button className="flex-1 bg-orange-600 hover:bg-orange-700" asChild>
                    <Link href={`/products/${product.id}`}>View Details</Link>
                  </Button>
                  <Button variant="outline" size="default">
                    <Package className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="default">
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg" asChild>
            <Link href="/products">View All Products</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
