"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, Filter } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ProductSearch() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showSuggestions, setShowSuggestions] = useState(false)

  const suggestions = [
    { name: "Hydraulic Pump", category: "Hydraulics", suppliers: 45 },
    { name: "Aviation Nut A7E", category: "Aerospace", suppliers: 12 },
    { name: "Industrial Valve", category: "Valves", suppliers: 78 },
    { name: "Bearing Assembly", category: "Mechanical", suppliers: 34 },
  ]

  return (
    <Card className="shadow-lg">
      <CardContent className="p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Main Search */}
          <div className="flex-1 relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search for parts, SKUs, manufacturers..."
              className="pl-10 h-12 text-lg"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value)
                setShowSuggestions(e.target.value.length > 0)
              }}
              onFocus={() => setShowSuggestions(searchQuery.length > 0)}
            />

            {/* Search Suggestions */}
            {showSuggestions && (
              <Card className="absolute top-full left-0 right-0 mt-1 z-10 shadow-lg">
                <CardContent className="p-2">
                  {suggestions.map((item, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 hover:bg-gray-50 rounded cursor-pointer"
                      onClick={() => {
                        setSearchQuery(item.name)
                        setShowSuggestions(false)
                      }}
                    >
                      <div className="flex items-center space-x-3">
                        <Search className="w-4 h-4 text-gray-400" />
                        <div>
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-gray-500">{item.category}</p>
                        </div>
                      </div>
                      <Badge variant="secondary">{item.suppliers} suppliers</Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Filters */}
          <div className="flex gap-2">
            <Select>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hydraulics">Hydraulics</SelectItem>
                <SelectItem value="aerospace">Aerospace</SelectItem>
                <SelectItem value="automotive">Automotive</SelectItem>
                <SelectItem value="industrial">Industrial</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="usa">United States</SelectItem>
                <SelectItem value="europe">Europe</SelectItem>
                <SelectItem value="asia">Asia Pacific</SelectItem>
                <SelectItem value="global">Global</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="default">
              <Filter className="w-4 h-4 mr-2" />
              More Filters
            </Button>
          </div>

          <Button size="default" className="bg-orange-600 hover:bg-orange-700 px-8">
            Search
          </Button>
        </div>

        {/* Quick Filters */}
        <div className="flex flex-wrap gap-2 mt-4">
          <Badge variant="outline" className="cursor-pointer hover:bg-gray-100">
            In Stock
          </Badge>
          <Badge variant="outline" className="cursor-pointer hover:bg-gray-100">
            ISO Certified
          </Badge>
          <Badge variant="outline" className="cursor-pointer hover:bg-gray-100">
            Same Day Shipping
          </Badge>
          <Badge variant="outline" className="cursor-pointer hover:bg-gray-100">
            Bulk Discount
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
