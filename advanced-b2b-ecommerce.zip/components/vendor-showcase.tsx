import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, MapPin, Award, Users, Package } from "lucide-react"
import Link from "next/link"

export default function VendorShowcase() {
  const vendors = [
    {
      id: 1,
      name: "Industrial Solutions Inc.",
      logo: "/placeholder.svg?height=80&width=80",
      rating: 4.9,
      location: "Ohio, USA",
      specialties: ["Hydraulics", "Pneumatics", "Automation"],
      certifications: ["ISO 9001", "ISO 14001", "OHSAS 18001"],
      yearsInBusiness: 25,
      totalProducts: 1250,
      responseTime: "< 2 hours",
      description: "Leading supplier of industrial hydraulic and pneumatic components with 25+ years of experience.",
    },
    {
      id: 2,
      name: "Precision Parts Co.",
      logo: "/placeholder.svg?height=80&width=80",
      rating: 4.8,
      location: "Michigan, USA",
      specialties: ["Bearings", "Seals", "Mechanical Components"],
      certifications: ["ISO 9001", "IATF 16949", "AS9100"],
      yearsInBusiness: 18,
      totalProducts: 890,
      responseTime: "< 4 hours",
      description: "Precision-engineered components for automotive, aerospace, and industrial applications.",
    },
    {
      id: 3,
      name: "Aerospace Components Ltd.",
      logo: "/placeholder.svg?height=80&width=80",
      rating: 4.9,
      location: "California, USA",
      specialties: ["Aerospace", "Defense", "High-Performance"],
      certifications: ["AS9100", "NADCAP", "ITAR"],
      yearsInBusiness: 32,
      totalProducts: 2100,
      responseTime: "< 1 hour",
      description: "Specialized aerospace and defense components meeting the highest industry standards.",
    },
    {
      id: 4,
      name: "Global Manufacturing Corp.",
      logo: "/placeholder.svg?height=80&width=80",
      rating: 4.7,
      location: "Texas, USA",
      specialties: ["Electronics", "Sensors", "Control Systems"],
      certifications: ["ISO 9001", "UL Listed", "RoHS"],
      yearsInBusiness: 15,
      totalProducts: 3400,
      responseTime: "< 3 hours",
      description: "Advanced electronic components and control systems for industrial automation.",
    },
  ]

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Certified Vendors & Suppliers</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Partner with industry-leading suppliers who meet our strict quality and compliance standards
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {vendors.map((vendor) => (
            <Card key={vendor.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                    <img
                      src={vendor.logo || "/placeholder.svg"}
                      alt={vendor.name}
                      className="w-12 h-12 object-contain"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-xl">{vendor.name}</CardTitle>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium">{vendor.rating}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-600">{vendor.location}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <CardDescription>{vendor.description}</CardDescription>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <Award className="w-4 h-4 text-orange-500" />
                    <span>{vendor.yearsInBusiness} years</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Package className="w-4 h-4 text-blue-500" />
                    <span>{vendor.totalProducts.toLocaleString()} products</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-green-500" />
                    <span>Response: {vendor.responseTime}</span>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Specialties</h4>
                  <div className="flex flex-wrap gap-1">
                    {vendor.specialties.map((specialty) => (
                      <Badge key={specialty} variant="outline">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Certifications</h4>
                  <div className="flex flex-wrap gap-1">
                    {vendor.certifications.map((cert) => (
                      <Badge key={cert} variant="secondary" className="bg-green-100 text-green-800">
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button className="flex-1" variant="outline" asChild>
                    <Link href={`/vendors/${vendor.id}`}>View Profile</Link>
                  </Button>
                  <Button className="flex-1 bg-orange-600 hover:bg-orange-700" asChild>
                    <Link href={`/vendors/${vendor.id}/products`}>Browse Products</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg" asChild>
            <Link href="/vendors">View All Vendors</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
