import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ShoppingCart, Package, TrendingUp, Clock, DollarSign, Users } from "lucide-react"
import Header from "@/components/header"
import Link from "next/link"

export default function DashboardPage() {
  const stats = [
    {
      title: "Total Orders",
      value: "1,247",
      change: "+12.5%",
      icon: ShoppingCart,
      color: "text-blue-600",
    },
    {
      title: "Active RFQs",
      value: "23",
      change: "+3",
      icon: Clock,
      color: "text-orange-600",
    },
    {
      title: "Monthly Spend",
      value: "$124,500",
      change: "-8.2%",
      icon: DollarSign,
      color: "text-green-600",
    },
    {
      title: "Suppliers",
      value: "156",
      change: "+5",
      icon: Users,
      color: "text-purple-600",
    },
  ]

  const recentOrders = [
    {
      id: "ORD-2024-001",
      supplier: "Industrial Solutions Inc.",
      items: 3,
      total: "$2,450.00",
      status: "Delivered",
      date: "2024-01-15",
    },
    {
      id: "ORD-2024-002",
      supplier: "Precision Parts Co.",
      items: 1,
      total: "$850.00",
      status: "In Transit",
      date: "2024-01-14",
    },
    {
      id: "ORD-2024-003",
      supplier: "Aerospace Components Ltd.",
      items: 5,
      total: "$3,200.00",
      status: "Processing",
      date: "2024-01-13",
    },
  ]

  const pendingRFQs = [
    {
      id: "RFQ-2024-045",
      product: "Hydraulic Valve A7E",
      quantity: 50,
      responses: 3,
      deadline: "2024-01-20",
      status: "Active",
    },
    {
      id: "RFQ-2024-046",
      product: "Precision Bearing Assembly",
      quantity: 100,
      responses: 1,
      deadline: "2024-01-22",
      status: "Active",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-2">Welcome back, John. Here's your procurement overview.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    <p className={`text-sm ${stat.change.startsWith("+") ? "text-green-600" : "text-red-600"}`}>
                      {stat.change} from last month
                    </p>
                  </div>
                  <div className={`p-3 rounded-full bg-gray-100 ${stat.color}`}>
                    <stat.icon className="w-6 h-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Recent Orders */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Orders</CardTitle>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/orders">View All</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">{order.id}</p>
                      <p className="text-sm text-gray-600">{order.supplier}</p>
                      <p className="text-sm text-gray-500">
                        {order.items} items • {order.date}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{order.total}</p>
                      <Badge
                        variant={
                          order.status === "Delivered"
                            ? "default"
                            : order.status === "In Transit"
                              ? "secondary"
                              : "outline"
                        }
                        className="mt-1"
                      >
                        {order.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Pending RFQs */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Pending RFQs</CardTitle>
                <Button variant="outline" size="sm" asChild>
                  <Link href="/rfq">View All</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingRFQs.map((rfq) => (
                  <div key={rfq.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-medium">{rfq.id}</p>
                      <Badge variant="outline">{rfq.status}</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{rfq.product}</p>
                    <div className="flex items-center justify-between text-sm">
                      <span>Qty: {rfq.quantity}</span>
                      <span>{rfq.responses} responses</span>
                      <span className="text-gray-500">Due: {rfq.deadline}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Spend Analysis */}
        <div className="grid lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Monthly Spend Analysis</CardTitle>
              <CardDescription>Procurement spending by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Hydraulics</span>
                    <span className="text-sm text-gray-600">$45,200 (36%)</span>
                  </div>
                  <Progress value={36} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Electronics</span>
                    <span className="text-sm text-gray-600">$32,100 (26%)</span>
                  </div>
                  <Progress value={26} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Mechanical</span>
                    <span className="text-sm text-gray-600">$28,500 (23%)</span>
                  </div>
                  <Progress value={23} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Other</span>
                    <span className="text-sm text-gray-600">$18,700 (15%)</span>
                  </div>
                  <Progress value={15} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start" variant="outline" asChild>
                <Link href="/rfq/new">
                  <Package className="w-4 h-4 mr-2" />
                  Create New RFQ
                </Link>
              </Button>
              <Button className="w-full justify-start" variant="outline" asChild>
                <Link href="/products">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Browse Catalog
                </Link>
              </Button>
              <Button className="w-full justify-start" variant="outline" asChild>
                <Link href="/analytics">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  View Analytics
                </Link>
              </Button>
              <Button className="w-full justify-start" variant="outline" asChild>
                <Link href="/vendors">
                  <Users className="w-4 h-4 mr-2" />
                  Manage Vendors
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
