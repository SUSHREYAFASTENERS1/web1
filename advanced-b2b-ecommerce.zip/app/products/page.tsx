"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Grid, List, Star, MapPin, Package, Download } from "lucide-react"
import Header from "@/components/header"
import Link from "next/link"

export default function ProductsPage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [sortBy, setSortBy] = useState("relevance")

  const products = [
    {
      id: 1,
      name: "Hydraulic Valve A7E",
      sku: "HV-A7E-2024",
      image: "/placeholder.svg?height=200&width=200",
      price: "$120.00",
      moq: "20 pcs",
      stock: 120,
      rating: 4.8,
      supplier: "Industrial Solutions Inc.",
      location: "Ohio, USA",
      certifications: ["ISO 9001", "CE"],
      leadTime: "3-5 days",
      category: "Hydraulics",
    },
    {
      id: 2,
      name: "Precision Bearing Assembly",
      sku: "PBA-X200",
      image: "/placeholder.svg?height=200&width=200",
      price: "$85.50",
      moq: "50 pcs",
      stock: 340,
      rating: 4.9,
      supplier: "Precision Parts Co.",
      location: "Michigan, USA",
      certifications: ["ISO 9001", "IATF 16949"],
      leadTime: "2-4 days",
      category: "Bearings",
    },
    {
      id: 3,
      name: "Aviation Grade Fastener",
      sku: "AGF-7750",
      image: "/placeholder.svg?height=200&width=200",
      price: "$15.75",
      moq: "100 pcs",
      stock: 850,
      rating: 4.7,
      supplier: "Aerospace Components Ltd.",
      location: "California, USA",
      certifications: ["AS9100", "NADCAP"],
      leadTime: "1-3 days",
      category: "Fasteners",
    },
    // Add more products...
  ]

  const categories = [
    { name: "Hydraulics", count: 1250 },
    { name: "Pneumatics", count: 890 },
    { name: "Bearings", count: 2100 },
    { name: "Fasteners", count: 3400 },
    { name: "Seals & Gaskets", count: 750 },
    { name: "Electronics", count: 1800 },
  ]

  const certifications = [
    { name: "ISO 9001", count: 2500 },
    { name: "AS9100", count: 450 },
    { name: "IATF 16949", count: 680 },
    { name: "CE", count: 1200 },
    { name: "UL Listed", count: 890 },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <div className="lg:w-64 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Filters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Categories */}
                <div>
                  <h3 className="font-medium mb-3">Categories</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <div key={category.name} className="flex items-center space-x-2">
                        <Checkbox id={category.name} />
                        <label htmlFor={category.name} className="text-sm flex-1 cursor-pointer">
                          {category.name}
                        </label>
                        <span className="text-xs text-gray-500">({category.count})</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div>
                  <h3 className="font-medium mb-3">Price Range</h3>
                  <div className="space-y-2">
                    <Input placeholder="Min price" />
                    <Input placeholder="Max price" />
                  </div>
                </div>

                {/* Certifications */}
                <div>
                  <h3 className="font-medium mb-3">Certifications</h3>
                  <div className="space-y-2">
                    {certifications.map((cert) => (
                      <div key={cert.name} className="flex items-center space-x-2">
                        <Checkbox id={cert.name} />
                        <label htmlFor={cert.name} className="text-sm flex-1 cursor-pointer">
                          {cert.name}
                        </label>
                        <span className="text-xs text-gray-500">({cert.count})</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stock Status */}
                <div>
                  <h3 className="font-medium mb-3">Availability</h3>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="in-stock" />
                      <label htmlFor="in-stock" className="text-sm cursor-pointer">
                        In Stock
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="same-day" />
                      <label htmlFor="same-day" className="text-sm cursor-pointer">
                        Same Day Shipping
                      </label>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Search and Controls */}
            <div className="mb-6">
              <div className="flex flex-col sm:flex-row gap-4 mb-4">
                <div className="flex-1 relative">
                  <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input placeholder="Search products..." className="pl-10" />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Advanced Filters
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">Showing 1-12 of 1,247 products</p>

                <div className="flex items-center space-x-4">
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevance">Relevance</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="rating">Highest Rated</SelectItem>
                      <SelectItem value="newest">Newest</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="flex border rounded">
                    <Button
                      variant={viewMode === "grid" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("grid")}
                    >
                      <Grid className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("list")}
                    >
                      <List className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Products Grid */}
            <div className={viewMode === "grid" ? "grid md:grid-cols-2 xl:grid-cols-3 gap-6" : "space-y-4"}>
              {products.map((product) => (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-4">
                    <div className="aspect-square bg-gray-100 rounded-lg mb-4 flex items-center justify-center">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className="w-32 h-32 object-contain"
                      />
                    </div>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{product.name}</CardTitle>
                        <CardDescription className="text-sm text-gray-500">SKU: {product.sku}</CardDescription>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{product.rating}</span>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="text-2xl font-bold text-orange-600">{product.price}</div>
                      <Badge variant="outline">MOQ: {product.moq}</Badge>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Stock:</span>
                        <span className="font-medium">{product.stock} pcs</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Lead Time:</span>
                        <span className="font-medium">{product.leadTime}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <MapPin className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-600">{product.supplier}</span>
                      </div>
                      <div className="text-sm text-gray-500">{product.location}</div>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {product.certifications.map((cert) => (
                        <Badge key={cert} variant="secondary" className="text-xs">
                          {cert}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex space-x-2 pt-4">
                      <Button className="flex-1 bg-orange-600 hover:bg-orange-700" asChild>
                        <Link href={`/products/${product.id}`}>View Details</Link>
                      </Button>
                      <Button variant="outline" size="default">
                        <Package className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="default">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center mt-12">
              <div className="flex space-x-2">
                <Button variant="outline" disabled>
                  Previous
                </Button>
                <Button variant="default">1</Button>
                <Button variant="outline">2</Button>
                <Button variant="outline">3</Button>
                <Button variant="outline">...</Button>
                <Button variant="outline">42</Button>
                <Button variant="outline">Next</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
